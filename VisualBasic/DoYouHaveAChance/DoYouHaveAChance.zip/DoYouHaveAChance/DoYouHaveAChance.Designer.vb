﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DoYouHaveAChance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lblAttractiveYou = New System.Windows.Forms.Label()
        Me.lblAttractiveHer = New System.Windows.Forms.Label()
        Me.lblRelationStatus = New System.Windows.Forms.Label()
        Me.lblConvoSkill = New System.Windows.Forms.Label()
        Me.lblSchoolYou = New System.Windows.Forms.Label()
        Me.lblSchoolHer = New System.Windows.Forms.Label()
        Me.lblAggressive = New System.Windows.Forms.Label()
        Me.lblCommonalities = New System.Windows.Forms.Label()
        Me.lblDifferences = New System.Windows.Forms.Label()
        Me.lblSalaryYou = New System.Windows.Forms.Label()
        Me.lblSalaryHer = New System.Windows.Forms.Label()
        Me.lblFamiliarity = New System.Windows.Forms.Label()
        Me.txtAttractiveYou = New System.Windows.Forms.TextBox()
        Me.txtAttractiveHer = New System.Windows.Forms.TextBox()
        Me.txtRelationStatus = New System.Windows.Forms.TextBox()
        Me.txtConvoSkill = New System.Windows.Forms.TextBox()
        Me.txtSchoolYou = New System.Windows.Forms.TextBox()
        Me.txtSchoolHer = New System.Windows.Forms.TextBox()
        Me.txtAggressive = New System.Windows.Forms.TextBox()
        Me.txtCommonalities = New System.Windows.Forms.TextBox()
        Me.txtDifferences = New System.Windows.Forms.TextBox()
        Me.txtFamiliarity = New System.Windows.Forms.TextBox()
        Me.txtSalaryYou = New System.Windows.Forms.TextBox()
        Me.txtSalaryHer = New System.Windows.Forms.TextBox()
        Me.lblAnswer = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(112, 395)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(257, 23)
        Me.btnCalculate.TabIndex = 12
        Me.btnCalculate.Text = "Click Here to Find Out If You Have a Chance!"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'lblAttractiveYou
        '
        Me.lblAttractiveYou.AutoSize = True
        Me.lblAttractiveYou.Location = New System.Drawing.Point(109, 17)
        Me.lblAttractiveYou.Name = "lblAttractiveYou"
        Me.lblAttractiveYou.Size = New System.Drawing.Size(320, 13)
        Me.lblAttractiveYou.TabIndex = 1
        Me.lblAttractiveYou.Text = "How attractive are you? (1-10 with 10 being ""I resemble Brad Pitt"")"
        '
        'lblAttractiveHer
        '
        Me.lblAttractiveHer.AutoSize = True
        Me.lblAttractiveHer.Location = New System.Drawing.Point(111, 48)
        Me.lblAttractiveHer.Name = "lblAttractiveHer"
        Me.lblAttractiveHer.Size = New System.Drawing.Size(318, 13)
        Me.lblAttractiveHer.TabIndex = 2
        Me.lblAttractiveHer.Text = "How attractive is she? (1-10 with 10 being ""Swedish supermodel"")"
        '
        'lblRelationStatus
        '
        Me.lblRelationStatus.AutoSize = True
        Me.lblRelationStatus.Location = New System.Drawing.Point(109, 79)
        Me.lblRelationStatus.Name = "lblRelationStatus"
        Me.lblRelationStatus.Size = New System.Drawing.Size(495, 13)
        Me.lblRelationStatus.TabIndex = 3
        Me.lblRelationStatus.Text = "Quantify her relationship status (0-10 with 0 being Sex and the City AND 10 being" & _
    " Married With Children)"
        '
        'lblConvoSkill
        '
        Me.lblConvoSkill.AutoSize = True
        Me.lblConvoSkill.Location = New System.Drawing.Point(109, 110)
        Me.lblConvoSkill.Name = "lblConvoSkill"
        Me.lblConvoSkill.Size = New System.Drawing.Size(450, 13)
        Me.lblConvoSkill.TabIndex = 4
        Me.lblConvoSkill.Text = "Are you a witty conversationalist? (1-10 with 1 being ""bowling ball"" and 10 being" & _
    " Woody Allen)"
        '
        'lblSchoolYou
        '
        Me.lblSchoolYou.AutoSize = True
        Me.lblSchoolYou.Location = New System.Drawing.Point(109, 141)
        Me.lblSchoolYou.Name = "lblSchoolYou"
        Me.lblSchoolYou.Size = New System.Drawing.Size(418, 13)
        Me.lblSchoolYou.TabIndex = 5
        Me.lblSchoolYou.Text = "How many grades of school have you completed? (high school = 12, college = 16, et" & _
    "c.)"
        '
        'lblSchoolHer
        '
        Me.lblSchoolHer.AutoSize = True
        Me.lblSchoolHer.Location = New System.Drawing.Point(109, 172)
        Me.lblSchoolHer.Name = "lblSchoolHer"
        Me.lblSchoolHer.Size = New System.Drawing.Size(411, 13)
        Me.lblSchoolHer.TabIndex = 6
        Me.lblSchoolHer.Text = "How many grades of school has she completed? (high school = 12, college = 16, etc" & _
    ".)"
        '
        'lblAggressive
        '
        Me.lblAggressive.AutoSize = True
        Me.lblAggressive.Location = New System.Drawing.Point(109, 203)
        Me.lblAggressive.Name = "lblAggressive"
        Me.lblAggressive.Size = New System.Drawing.Size(528, 13)
        Me.lblAggressive.TabIndex = 7
        Me.lblAggressive.Text = "How aggressive are you willing to be (1-10 with 10 being ""will be under her windo" & _
    "w with guitar in hand tonight"")"
        '
        'lblCommonalities
        '
        Me.lblCommonalities.AutoSize = True
        Me.lblCommonalities.Location = New System.Drawing.Point(109, 234)
        Me.lblCommonalities.Name = "lblCommonalities"
        Me.lblCommonalities.Size = New System.Drawing.Size(364, 13)
        Me.lblCommonalities.TabIndex = 8
        Me.lblCommonalities.Text = "How many things can you think of that you and she might have in common?"
        '
        'lblDifferences
        '
        Me.lblDifferences.AutoSize = True
        Me.lblDifferences.Location = New System.Drawing.Point(109, 265)
        Me.lblDifferences.Name = "lblDifferences"
        Me.lblDifferences.Size = New System.Drawing.Size(312, 13)
        Me.lblDifferences.TabIndex = 9
        Me.lblDifferences.Text = "How many important differences are there between you and her?"
        '
        'lblSalaryYou
        '
        Me.lblSalaryYou.AutoSize = True
        Me.lblSalaryYou.Location = New System.Drawing.Point(109, 296)
        Me.lblSalaryYou.Name = "lblSalaryYou"
        Me.lblSalaryYou.Size = New System.Drawing.Size(185, 13)
        Me.lblSalaryYou.TabIndex = 10
        Me.lblSalaryYou.Text = "What is your monthly salary in dollars?"
        '
        'lblSalaryHer
        '
        Me.lblSalaryHer.AutoSize = True
        Me.lblSalaryHer.Location = New System.Drawing.Point(109, 327)
        Me.lblSalaryHer.Name = "lblSalaryHer"
        Me.lblSalaryHer.Size = New System.Drawing.Size(245, 13)
        Me.lblSalaryHer.TabIndex = 11
        Me.lblSalaryHer.Text = "What do you think her estimated monthly salary is?"
        '
        'lblFamiliarity
        '
        Me.lblFamiliarity.AutoSize = True
        Me.lblFamiliarity.Location = New System.Drawing.Point(109, 358)
        Me.lblFamiliarity.Name = "lblFamiliarity"
        Me.lblFamiliarity.Size = New System.Drawing.Size(358, 13)
        Me.lblFamiliarity.TabIndex = 12
        Me.lblFamiliarity.Text = "How well does she know you? (1 - 10 with 10 being ""She's my psychiatrist)"
        '
        'txtAttractiveYou
        '
        Me.txtAttractiveYou.Location = New System.Drawing.Point(64, 14)
        Me.txtAttractiveYou.Name = "txtAttractiveYou"
        Me.txtAttractiveYou.Size = New System.Drawing.Size(39, 20)
        Me.txtAttractiveYou.TabIndex = 0
        '
        'txtAttractiveHer
        '
        Me.txtAttractiveHer.Location = New System.Drawing.Point(66, 45)
        Me.txtAttractiveHer.Name = "txtAttractiveHer"
        Me.txtAttractiveHer.Size = New System.Drawing.Size(39, 20)
        Me.txtAttractiveHer.TabIndex = 1
        '
        'txtRelationStatus
        '
        Me.txtRelationStatus.Location = New System.Drawing.Point(66, 76)
        Me.txtRelationStatus.Name = "txtRelationStatus"
        Me.txtRelationStatus.Size = New System.Drawing.Size(39, 20)
        Me.txtRelationStatus.TabIndex = 2
        '
        'txtConvoSkill
        '
        Me.txtConvoSkill.Location = New System.Drawing.Point(66, 107)
        Me.txtConvoSkill.Name = "txtConvoSkill"
        Me.txtConvoSkill.Size = New System.Drawing.Size(39, 20)
        Me.txtConvoSkill.TabIndex = 3
        '
        'txtSchoolYou
        '
        Me.txtSchoolYou.Location = New System.Drawing.Point(66, 138)
        Me.txtSchoolYou.Name = "txtSchoolYou"
        Me.txtSchoolYou.Size = New System.Drawing.Size(39, 20)
        Me.txtSchoolYou.TabIndex = 4
        '
        'txtSchoolHer
        '
        Me.txtSchoolHer.Location = New System.Drawing.Point(66, 169)
        Me.txtSchoolHer.Name = "txtSchoolHer"
        Me.txtSchoolHer.Size = New System.Drawing.Size(39, 20)
        Me.txtSchoolHer.TabIndex = 5
        '
        'txtAggressive
        '
        Me.txtAggressive.Location = New System.Drawing.Point(66, 200)
        Me.txtAggressive.Name = "txtAggressive"
        Me.txtAggressive.Size = New System.Drawing.Size(39, 20)
        Me.txtAggressive.TabIndex = 6
        '
        'txtCommonalities
        '
        Me.txtCommonalities.Location = New System.Drawing.Point(66, 231)
        Me.txtCommonalities.Name = "txtCommonalities"
        Me.txtCommonalities.Size = New System.Drawing.Size(39, 20)
        Me.txtCommonalities.TabIndex = 7
        '
        'txtDifferences
        '
        Me.txtDifferences.Location = New System.Drawing.Point(66, 262)
        Me.txtDifferences.Name = "txtDifferences"
        Me.txtDifferences.Size = New System.Drawing.Size(39, 20)
        Me.txtDifferences.TabIndex = 8
        '
        'txtFamiliarity
        '
        Me.txtFamiliarity.Location = New System.Drawing.Point(66, 355)
        Me.txtFamiliarity.Name = "txtFamiliarity"
        Me.txtFamiliarity.Size = New System.Drawing.Size(39, 20)
        Me.txtFamiliarity.TabIndex = 11
        '
        'txtSalaryYou
        '
        Me.txtSalaryYou.Location = New System.Drawing.Point(53, 293)
        Me.txtSalaryYou.Name = "txtSalaryYou"
        Me.txtSalaryYou.Size = New System.Drawing.Size(52, 20)
        Me.txtSalaryYou.TabIndex = 9
        '
        'txtSalaryHer
        '
        Me.txtSalaryHer.Location = New System.Drawing.Point(53, 324)
        Me.txtSalaryHer.Name = "txtSalaryHer"
        Me.txtSalaryHer.Size = New System.Drawing.Size(52, 20)
        Me.txtSalaryHer.TabIndex = 10
        '
        'lblAnswer
        '
        Me.lblAnswer.AutoSize = True
        Me.lblAnswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAnswer.Location = New System.Drawing.Point(62, 444)
        Me.lblAnswer.Name = "lblAnswer"
        Me.lblAnswer.Size = New System.Drawing.Size(68, 20)
        Me.lblAnswer.TabIndex = 13
        Me.lblAnswer.Text = "Answer"
        Me.lblAnswer.Visible = False
        '
        'DoYouHaveAChance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(662, 491)
        Me.Controls.Add(Me.lblAnswer)
        Me.Controls.Add(Me.txtSalaryHer)
        Me.Controls.Add(Me.txtSalaryYou)
        Me.Controls.Add(Me.txtFamiliarity)
        Me.Controls.Add(Me.txtDifferences)
        Me.Controls.Add(Me.txtCommonalities)
        Me.Controls.Add(Me.txtAggressive)
        Me.Controls.Add(Me.txtSchoolHer)
        Me.Controls.Add(Me.txtSchoolYou)
        Me.Controls.Add(Me.txtConvoSkill)
        Me.Controls.Add(Me.txtRelationStatus)
        Me.Controls.Add(Me.txtAttractiveHer)
        Me.Controls.Add(Me.txtAttractiveYou)
        Me.Controls.Add(Me.lblFamiliarity)
        Me.Controls.Add(Me.lblSalaryHer)
        Me.Controls.Add(Me.lblSalaryYou)
        Me.Controls.Add(Me.lblDifferences)
        Me.Controls.Add(Me.lblCommonalities)
        Me.Controls.Add(Me.lblAggressive)
        Me.Controls.Add(Me.lblSchoolHer)
        Me.Controls.Add(Me.lblSchoolYou)
        Me.Controls.Add(Me.lblConvoSkill)
        Me.Controls.Add(Me.lblRelationStatus)
        Me.Controls.Add(Me.lblAttractiveHer)
        Me.Controls.Add(Me.lblAttractiveYou)
        Me.Controls.Add(Me.btnCalculate)
        Me.Name = "DoYouHaveAChance"
        Me.Text = "Do You Have a Chance?"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents lblAttractiveYou As System.Windows.Forms.Label
    Friend WithEvents lblAttractiveHer As System.Windows.Forms.Label
    Friend WithEvents lblRelationStatus As System.Windows.Forms.Label
    Friend WithEvents lblConvoSkill As System.Windows.Forms.Label
    Friend WithEvents lblSchoolYou As System.Windows.Forms.Label
    Friend WithEvents lblSchoolHer As System.Windows.Forms.Label
    Friend WithEvents lblAggressive As System.Windows.Forms.Label
    Friend WithEvents lblCommonalities As System.Windows.Forms.Label
    Friend WithEvents lblDifferences As System.Windows.Forms.Label
    Friend WithEvents lblSalaryYou As System.Windows.Forms.Label
    Friend WithEvents lblSalaryHer As System.Windows.Forms.Label
    Friend WithEvents lblFamiliarity As System.Windows.Forms.Label
    Friend WithEvents txtAttractiveYou As System.Windows.Forms.TextBox
    Friend WithEvents txtAttractiveHer As System.Windows.Forms.TextBox
    Friend WithEvents txtRelationStatus As System.Windows.Forms.TextBox
    Friend WithEvents txtConvoSkill As System.Windows.Forms.TextBox
    Friend WithEvents txtSchoolYou As System.Windows.Forms.TextBox
    Friend WithEvents txtSchoolHer As System.Windows.Forms.TextBox
    Friend WithEvents txtAggressive As System.Windows.Forms.TextBox
    Friend WithEvents txtCommonalities As System.Windows.Forms.TextBox
    Friend WithEvents txtDifferences As System.Windows.Forms.TextBox
    Friend WithEvents txtFamiliarity As System.Windows.Forms.TextBox
    Friend WithEvents txtSalaryYou As System.Windows.Forms.TextBox
    Friend WithEvents txtSalaryHer As System.Windows.Forms.TextBox
    Friend WithEvents lblAnswer As System.Windows.Forms.Label

End Class
