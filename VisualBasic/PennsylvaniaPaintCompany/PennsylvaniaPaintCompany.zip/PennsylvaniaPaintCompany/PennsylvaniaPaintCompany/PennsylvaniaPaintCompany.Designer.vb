﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PennsylvaniaPaintCompany
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpRoomDims = New System.Windows.Forms.GroupBox()
        Me.txtRoomHeight = New System.Windows.Forms.TextBox()
        Me.lblRoomHeight = New System.Windows.Forms.Label()
        Me.txtRoomLength = New System.Windows.Forms.TextBox()
        Me.lblRoomLength = New System.Windows.Forms.Label()
        Me.lblRoomWidth = New System.Windows.Forms.Label()
        Me.txtRoomWidth = New System.Windows.Forms.TextBox()
        Me.grpWallSA = New System.Windows.Forms.GroupBox()
        Me.txtTotalWallSA = New System.Windows.Forms.TextBox()
        Me.lblWallTotal = New System.Windows.Forms.Label()
        Me.txtCeilingSA = New System.Windows.Forms.TextBox()
        Me.txtWall4SA = New System.Windows.Forms.TextBox()
        Me.txtWall3SA = New System.Windows.Forms.TextBox()
        Me.txtWall2SA = New System.Windows.Forms.TextBox()
        Me.txtWall1SA = New System.Windows.Forms.TextBox()
        Me.lblCeilingSA = New System.Windows.Forms.Label()
        Me.lblWall4SA = New System.Windows.Forms.Label()
        Me.lblWall3SA = New System.Windows.Forms.Label()
        Me.lblWall2SA = New System.Windows.Forms.Label()
        Me.lblWall1SA = New System.Windows.Forms.Label()
        Me.grpWin = New System.Windows.Forms.GroupBox()
        Me.txtTotalWinSA = New System.Windows.Forms.TextBox()
        Me.lblWin8 = New System.Windows.Forms.Label()
        Me.lblWinTotal = New System.Windows.Forms.Label()
        Me.lblWin7 = New System.Windows.Forms.Label()
        Me.lblWin6 = New System.Windows.Forms.Label()
        Me.lblWin5 = New System.Windows.Forms.Label()
        Me.lblWin4 = New System.Windows.Forms.Label()
        Me.lblWin3 = New System.Windows.Forms.Label()
        Me.lblWin2 = New System.Windows.Forms.Label()
        Me.lblWin1 = New System.Windows.Forms.Label()
        Me.lblWinSA = New System.Windows.Forms.Label()
        Me.txtWin8SA = New System.Windows.Forms.TextBox()
        Me.txtWin8Width = New System.Windows.Forms.TextBox()
        Me.txtWin8Length = New System.Windows.Forms.TextBox()
        Me.txtWin7SA = New System.Windows.Forms.TextBox()
        Me.txtWin7Width = New System.Windows.Forms.TextBox()
        Me.txtWin7Length = New System.Windows.Forms.TextBox()
        Me.txtWin6SA = New System.Windows.Forms.TextBox()
        Me.txtWin6Width = New System.Windows.Forms.TextBox()
        Me.txtWin6Length = New System.Windows.Forms.TextBox()
        Me.txtWin5SA = New System.Windows.Forms.TextBox()
        Me.txtWin5Width = New System.Windows.Forms.TextBox()
        Me.txtWin5Length = New System.Windows.Forms.TextBox()
        Me.txtWin4SA = New System.Windows.Forms.TextBox()
        Me.txtWin4Width = New System.Windows.Forms.TextBox()
        Me.txtWin4Length = New System.Windows.Forms.TextBox()
        Me.txtWin3SA = New System.Windows.Forms.TextBox()
        Me.txtWin3Width = New System.Windows.Forms.TextBox()
        Me.txtWin3Length = New System.Windows.Forms.TextBox()
        Me.txtWin2SA = New System.Windows.Forms.TextBox()
        Me.txtWin1SA = New System.Windows.Forms.TextBox()
        Me.txtWin2Width = New System.Windows.Forms.TextBox()
        Me.txtWin2Length = New System.Windows.Forms.TextBox()
        Me.txtWin1Width = New System.Windows.Forms.TextBox()
        Me.txtWin1Length = New System.Windows.Forms.TextBox()
        Me.lblWinWidth = New System.Windows.Forms.Label()
        Me.lblWinLength = New System.Windows.Forms.Label()
        Me.grpDoor = New System.Windows.Forms.GroupBox()
        Me.txtTotalDoorSA = New System.Windows.Forms.TextBox()
        Me.lblDoorTotal = New System.Windows.Forms.Label()
        Me.lblDoor4 = New System.Windows.Forms.Label()
        Me.lblDoorSA = New System.Windows.Forms.Label()
        Me.lblDoor3 = New System.Windows.Forms.Label()
        Me.lblDoor2 = New System.Windows.Forms.Label()
        Me.txtDoor4SA = New System.Windows.Forms.TextBox()
        Me.lblDoor1 = New System.Windows.Forms.Label()
        Me.txtDoor4Width = New System.Windows.Forms.TextBox()
        Me.txtDoor4Length = New System.Windows.Forms.TextBox()
        Me.txtDoor3SA = New System.Windows.Forms.TextBox()
        Me.txtDoor3Width = New System.Windows.Forms.TextBox()
        Me.txtDoor3Length = New System.Windows.Forms.TextBox()
        Me.txtDoor2SA = New System.Windows.Forms.TextBox()
        Me.txtDoor1SA = New System.Windows.Forms.TextBox()
        Me.txtDoor2Width = New System.Windows.Forms.TextBox()
        Me.txtDoor2Length = New System.Windows.Forms.TextBox()
        Me.txtDoor1Width = New System.Windows.Forms.TextBox()
        Me.txtDoor1Length = New System.Windows.Forms.TextBox()
        Me.lblDoorWidth = New System.Windows.Forms.Label()
        Me.lblDoorLength = New System.Windows.Forms.Label()
        Me.lblPaint = New System.Windows.Forms.Label()
        Me.txtPaint = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.grpRoomDims.SuspendLayout()
        Me.grpWallSA.SuspendLayout()
        Me.grpWin.SuspendLayout()
        Me.grpDoor.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpRoomDims
        '
        Me.grpRoomDims.Controls.Add(Me.txtRoomHeight)
        Me.grpRoomDims.Controls.Add(Me.lblRoomHeight)
        Me.grpRoomDims.Controls.Add(Me.txtRoomLength)
        Me.grpRoomDims.Controls.Add(Me.lblRoomLength)
        Me.grpRoomDims.Controls.Add(Me.lblRoomWidth)
        Me.grpRoomDims.Controls.Add(Me.txtRoomWidth)
        Me.grpRoomDims.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpRoomDims.Location = New System.Drawing.Point(12, 12)
        Me.grpRoomDims.Name = "grpRoomDims"
        Me.grpRoomDims.Size = New System.Drawing.Size(229, 163)
        Me.grpRoomDims.TabIndex = 0
        Me.grpRoomDims.TabStop = False
        Me.grpRoomDims.Text = "Please Enter the Room Dimensions in the Boxes Below."
        '
        'txtRoomHeight
        '
        Me.txtRoomHeight.Location = New System.Drawing.Point(87, 129)
        Me.txtRoomHeight.Name = "txtRoomHeight"
        Me.txtRoomHeight.Size = New System.Drawing.Size(100, 20)
        Me.txtRoomHeight.TabIndex = 5
        Me.txtRoomHeight.Text = "0"
        '
        'lblRoomHeight
        '
        Me.lblRoomHeight.AutoSize = True
        Me.lblRoomHeight.Location = New System.Drawing.Point(42, 129)
        Me.lblRoomHeight.Name = "lblRoomHeight"
        Me.lblRoomHeight.Size = New System.Drawing.Size(44, 13)
        Me.lblRoomHeight.TabIndex = 4
        Me.lblRoomHeight.Text = "Height"
        '
        'txtRoomLength
        '
        Me.txtRoomLength.Location = New System.Drawing.Point(87, 39)
        Me.txtRoomLength.Name = "txtRoomLength"
        Me.txtRoomLength.Size = New System.Drawing.Size(100, 20)
        Me.txtRoomLength.TabIndex = 3
        Me.txtRoomLength.Text = "0"
        '
        'lblRoomLength
        '
        Me.lblRoomLength.AutoSize = True
        Me.lblRoomLength.Location = New System.Drawing.Point(41, 42)
        Me.lblRoomLength.Name = "lblRoomLength"
        Me.lblRoomLength.Size = New System.Drawing.Size(46, 13)
        Me.lblRoomLength.TabIndex = 2
        Me.lblRoomLength.Text = "Length"
        '
        'lblRoomWidth
        '
        Me.lblRoomWidth.AutoSize = True
        Me.lblRoomWidth.Location = New System.Drawing.Point(46, 86)
        Me.lblRoomWidth.Name = "lblRoomWidth"
        Me.lblRoomWidth.Size = New System.Drawing.Size(40, 13)
        Me.lblRoomWidth.TabIndex = 1
        Me.lblRoomWidth.Text = "Width"
        '
        'txtRoomWidth
        '
        Me.txtRoomWidth.Location = New System.Drawing.Point(87, 83)
        Me.txtRoomWidth.Name = "txtRoomWidth"
        Me.txtRoomWidth.Size = New System.Drawing.Size(100, 20)
        Me.txtRoomWidth.TabIndex = 0
        Me.txtRoomWidth.Text = "0"
        '
        'grpWallSA
        '
        Me.grpWallSA.Controls.Add(Me.txtTotalWallSA)
        Me.grpWallSA.Controls.Add(Me.lblWallTotal)
        Me.grpWallSA.Controls.Add(Me.txtCeilingSA)
        Me.grpWallSA.Controls.Add(Me.txtWall4SA)
        Me.grpWallSA.Controls.Add(Me.txtWall3SA)
        Me.grpWallSA.Controls.Add(Me.txtWall2SA)
        Me.grpWallSA.Controls.Add(Me.txtWall1SA)
        Me.grpWallSA.Controls.Add(Me.lblCeilingSA)
        Me.grpWallSA.Controls.Add(Me.lblWall4SA)
        Me.grpWallSA.Controls.Add(Me.lblWall3SA)
        Me.grpWallSA.Controls.Add(Me.lblWall2SA)
        Me.grpWallSA.Controls.Add(Me.lblWall1SA)
        Me.grpWallSA.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpWallSA.Location = New System.Drawing.Point(12, 181)
        Me.grpWallSA.Name = "grpWallSA"
        Me.grpWallSA.Size = New System.Drawing.Size(229, 301)
        Me.grpWallSA.TabIndex = 6
        Me.grpWallSA.TabStop = False
        Me.grpWallSA.Text = "Wall Surface Area"
        '
        'txtTotalWallSA
        '
        Me.txtTotalWallSA.Enabled = False
        Me.txtTotalWallSA.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalWallSA.Location = New System.Drawing.Point(100, 235)
        Me.txtTotalWallSA.Name = "txtTotalWallSA"
        Me.txtTotalWallSA.Size = New System.Drawing.Size(100, 26)
        Me.txtTotalWallSA.TabIndex = 11
        '
        'lblWallTotal
        '
        Me.lblWallTotal.AutoSize = True
        Me.lblWallTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWallTotal.Location = New System.Drawing.Point(37, 238)
        Me.lblWallTotal.Name = "lblWallTotal"
        Me.lblWallTotal.Size = New System.Drawing.Size(49, 20)
        Me.lblWallTotal.TabIndex = 10
        Me.lblWallTotal.Text = "Total"
        '
        'txtCeilingSA
        '
        Me.txtCeilingSA.Enabled = False
        Me.txtCeilingSA.Location = New System.Drawing.Point(100, 182)
        Me.txtCeilingSA.Name = "txtCeilingSA"
        Me.txtCeilingSA.Size = New System.Drawing.Size(100, 20)
        Me.txtCeilingSA.TabIndex = 9
        '
        'txtWall4SA
        '
        Me.txtWall4SA.Enabled = False
        Me.txtWall4SA.Location = New System.Drawing.Point(99, 145)
        Me.txtWall4SA.Name = "txtWall4SA"
        Me.txtWall4SA.Size = New System.Drawing.Size(100, 20)
        Me.txtWall4SA.TabIndex = 8
        '
        'txtWall3SA
        '
        Me.txtWall3SA.Enabled = False
        Me.txtWall3SA.Location = New System.Drawing.Point(99, 107)
        Me.txtWall3SA.Name = "txtWall3SA"
        Me.txtWall3SA.Size = New System.Drawing.Size(100, 20)
        Me.txtWall3SA.TabIndex = 7
        '
        'txtWall2SA
        '
        Me.txtWall2SA.Enabled = False
        Me.txtWall2SA.Location = New System.Drawing.Point(100, 69)
        Me.txtWall2SA.Name = "txtWall2SA"
        Me.txtWall2SA.Size = New System.Drawing.Size(100, 20)
        Me.txtWall2SA.TabIndex = 6
        '
        'txtWall1SA
        '
        Me.txtWall1SA.Enabled = False
        Me.txtWall1SA.Location = New System.Drawing.Point(99, 31)
        Me.txtWall1SA.Name = "txtWall1SA"
        Me.txtWall1SA.Size = New System.Drawing.Size(100, 20)
        Me.txtWall1SA.TabIndex = 5
        '
        'lblCeilingSA
        '
        Me.lblCeilingSA.AutoSize = True
        Me.lblCeilingSA.Location = New System.Drawing.Point(42, 189)
        Me.lblCeilingSA.Name = "lblCeilingSA"
        Me.lblCeilingSA.Size = New System.Drawing.Size(45, 13)
        Me.lblCeilingSA.TabIndex = 4
        Me.lblCeilingSA.Text = "Ceiling"
        '
        'lblWall4SA
        '
        Me.lblWall4SA.AutoSize = True
        Me.lblWall4SA.Location = New System.Drawing.Point(21, 148)
        Me.lblWall4SA.Name = "lblWall4SA"
        Me.lblWall4SA.Size = New System.Drawing.Size(72, 13)
        Me.lblWall4SA.TabIndex = 3
        Me.lblWall4SA.Text = "Fourth Wall"
        '
        'lblWall3SA
        '
        Me.lblWall3SA.AutoSize = True
        Me.lblWall3SA.Location = New System.Drawing.Point(28, 114)
        Me.lblWall3SA.Name = "lblWall3SA"
        Me.lblWall3SA.Size = New System.Drawing.Size(65, 13)
        Me.lblWall3SA.TabIndex = 2
        Me.lblWall3SA.Text = "Third Wall"
        '
        'lblWall2SA
        '
        Me.lblWall2SA.AutoSize = True
        Me.lblWall2SA.Location = New System.Drawing.Point(13, 76)
        Me.lblWall2SA.Name = "lblWall2SA"
        Me.lblWall2SA.Size = New System.Drawing.Size(79, 13)
        Me.lblWall2SA.TabIndex = 1
        Me.lblWall2SA.Text = "Second Wall"
        '
        'lblWall1SA
        '
        Me.lblWall1SA.AutoSize = True
        Me.lblWall1SA.Location = New System.Drawing.Point(27, 38)
        Me.lblWall1SA.Name = "lblWall1SA"
        Me.lblWall1SA.Size = New System.Drawing.Size(60, 13)
        Me.lblWall1SA.TabIndex = 0
        Me.lblWall1SA.Text = "First Wall"
        '
        'grpWin
        '
        Me.grpWin.Controls.Add(Me.txtTotalWinSA)
        Me.grpWin.Controls.Add(Me.lblWin8)
        Me.grpWin.Controls.Add(Me.lblWinTotal)
        Me.grpWin.Controls.Add(Me.lblWin7)
        Me.grpWin.Controls.Add(Me.lblWin6)
        Me.grpWin.Controls.Add(Me.lblWin5)
        Me.grpWin.Controls.Add(Me.lblWin4)
        Me.grpWin.Controls.Add(Me.lblWin3)
        Me.grpWin.Controls.Add(Me.lblWin2)
        Me.grpWin.Controls.Add(Me.lblWin1)
        Me.grpWin.Controls.Add(Me.lblWinSA)
        Me.grpWin.Controls.Add(Me.txtWin8SA)
        Me.grpWin.Controls.Add(Me.txtWin8Width)
        Me.grpWin.Controls.Add(Me.txtWin8Length)
        Me.grpWin.Controls.Add(Me.txtWin7SA)
        Me.grpWin.Controls.Add(Me.txtWin7Width)
        Me.grpWin.Controls.Add(Me.txtWin7Length)
        Me.grpWin.Controls.Add(Me.txtWin6SA)
        Me.grpWin.Controls.Add(Me.txtWin6Width)
        Me.grpWin.Controls.Add(Me.txtWin6Length)
        Me.grpWin.Controls.Add(Me.txtWin5SA)
        Me.grpWin.Controls.Add(Me.txtWin5Width)
        Me.grpWin.Controls.Add(Me.txtWin5Length)
        Me.grpWin.Controls.Add(Me.txtWin4SA)
        Me.grpWin.Controls.Add(Me.txtWin4Width)
        Me.grpWin.Controls.Add(Me.txtWin4Length)
        Me.grpWin.Controls.Add(Me.txtWin3SA)
        Me.grpWin.Controls.Add(Me.txtWin3Width)
        Me.grpWin.Controls.Add(Me.txtWin3Length)
        Me.grpWin.Controls.Add(Me.txtWin2SA)
        Me.grpWin.Controls.Add(Me.txtWin1SA)
        Me.grpWin.Controls.Add(Me.txtWin2Width)
        Me.grpWin.Controls.Add(Me.txtWin2Length)
        Me.grpWin.Controls.Add(Me.txtWin1Width)
        Me.grpWin.Controls.Add(Me.txtWin1Length)
        Me.grpWin.Controls.Add(Me.lblWinWidth)
        Me.grpWin.Controls.Add(Me.lblWinLength)
        Me.grpWin.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpWin.Location = New System.Drawing.Point(250, 13)
        Me.grpWin.Name = "grpWin"
        Me.grpWin.Size = New System.Drawing.Size(471, 295)
        Me.grpWin.TabIndex = 1
        Me.grpWin.TabStop = False
        Me.grpWin.Text = "Please Enter the Window Dimensions in the Boxes Below"
        '
        'txtTotalWinSA
        '
        Me.txtTotalWinSA.Enabled = False
        Me.txtTotalWinSA.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalWinSA.Location = New System.Drawing.Point(356, 260)
        Me.txtTotalWinSA.Name = "txtTotalWinSA"
        Me.txtTotalWinSA.Size = New System.Drawing.Size(100, 26)
        Me.txtTotalWinSA.TabIndex = 39
        '
        'lblWin8
        '
        Me.lblWin8.AutoSize = True
        Me.lblWin8.Location = New System.Drawing.Point(12, 237)
        Me.lblWin8.Name = "lblWin8"
        Me.lblWin8.Size = New System.Drawing.Size(63, 13)
        Me.lblWin8.TabIndex = 34
        Me.lblWin8.Text = "Window 8"
        '
        'lblWinTotal
        '
        Me.lblWinTotal.AutoSize = True
        Me.lblWinTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWinTotal.Location = New System.Drawing.Point(269, 263)
        Me.lblWinTotal.Name = "lblWinTotal"
        Me.lblWinTotal.Size = New System.Drawing.Size(49, 20)
        Me.lblWinTotal.TabIndex = 40
        Me.lblWinTotal.Text = "Total"
        '
        'lblWin7
        '
        Me.lblWin7.AutoSize = True
        Me.lblWin7.Location = New System.Drawing.Point(12, 211)
        Me.lblWin7.Name = "lblWin7"
        Me.lblWin7.Size = New System.Drawing.Size(63, 13)
        Me.lblWin7.TabIndex = 33
        Me.lblWin7.Text = "Window 7"
        '
        'lblWin6
        '
        Me.lblWin6.AutoSize = True
        Me.lblWin6.Location = New System.Drawing.Point(12, 186)
        Me.lblWin6.Name = "lblWin6"
        Me.lblWin6.Size = New System.Drawing.Size(63, 13)
        Me.lblWin6.TabIndex = 32
        Me.lblWin6.Text = "Window 6"
        '
        'lblWin5
        '
        Me.lblWin5.AutoSize = True
        Me.lblWin5.Location = New System.Drawing.Point(12, 160)
        Me.lblWin5.Name = "lblWin5"
        Me.lblWin5.Size = New System.Drawing.Size(63, 13)
        Me.lblWin5.TabIndex = 31
        Me.lblWin5.Text = "Window 5"
        '
        'lblWin4
        '
        Me.lblWin4.AutoSize = True
        Me.lblWin4.Location = New System.Drawing.Point(12, 134)
        Me.lblWin4.Name = "lblWin4"
        Me.lblWin4.Size = New System.Drawing.Size(63, 13)
        Me.lblWin4.TabIndex = 30
        Me.lblWin4.Text = "Window 4"
        '
        'lblWin3
        '
        Me.lblWin3.AutoSize = True
        Me.lblWin3.Location = New System.Drawing.Point(12, 108)
        Me.lblWin3.Name = "lblWin3"
        Me.lblWin3.Size = New System.Drawing.Size(63, 13)
        Me.lblWin3.TabIndex = 29
        Me.lblWin3.Text = "Window 3"
        '
        'lblWin2
        '
        Me.lblWin2.AutoSize = True
        Me.lblWin2.Location = New System.Drawing.Point(12, 83)
        Me.lblWin2.Name = "lblWin2"
        Me.lblWin2.Size = New System.Drawing.Size(63, 13)
        Me.lblWin2.TabIndex = 28
        Me.lblWin2.Text = "Window 2"
        '
        'lblWin1
        '
        Me.lblWin1.AutoSize = True
        Me.lblWin1.Location = New System.Drawing.Point(12, 57)
        Me.lblWin1.Name = "lblWin1"
        Me.lblWin1.Size = New System.Drawing.Size(63, 13)
        Me.lblWin1.TabIndex = 27
        Me.lblWin1.Text = "Window 1"
        '
        'lblWinSA
        '
        Me.lblWinSA.AutoSize = True
        Me.lblWinSA.Location = New System.Drawing.Point(366, 30)
        Me.lblWinSA.Name = "lblWinSA"
        Me.lblWinSA.Size = New System.Drawing.Size(81, 13)
        Me.lblWinSA.TabIndex = 26
        Me.lblWinSA.Text = "Surface Area"
        '
        'txtWin8SA
        '
        Me.txtWin8SA.Enabled = False
        Me.txtWin8SA.Location = New System.Drawing.Point(356, 235)
        Me.txtWin8SA.Name = "txtWin8SA"
        Me.txtWin8SA.Size = New System.Drawing.Size(100, 20)
        Me.txtWin8SA.TabIndex = 25
        '
        'txtWin8Width
        '
        Me.txtWin8Width.Location = New System.Drawing.Point(218, 235)
        Me.txtWin8Width.Name = "txtWin8Width"
        Me.txtWin8Width.Size = New System.Drawing.Size(100, 20)
        Me.txtWin8Width.TabIndex = 24
        Me.txtWin8Width.Text = "0"
        '
        'txtWin8Length
        '
        Me.txtWin8Length.Location = New System.Drawing.Point(81, 235)
        Me.txtWin8Length.Name = "txtWin8Length"
        Me.txtWin8Length.Size = New System.Drawing.Size(100, 20)
        Me.txtWin8Length.TabIndex = 23
        Me.txtWin8Length.Text = "0"
        '
        'txtWin7SA
        '
        Me.txtWin7SA.Enabled = False
        Me.txtWin7SA.Location = New System.Drawing.Point(356, 209)
        Me.txtWin7SA.Name = "txtWin7SA"
        Me.txtWin7SA.Size = New System.Drawing.Size(100, 20)
        Me.txtWin7SA.TabIndex = 22
        '
        'txtWin7Width
        '
        Me.txtWin7Width.Location = New System.Drawing.Point(218, 209)
        Me.txtWin7Width.Name = "txtWin7Width"
        Me.txtWin7Width.Size = New System.Drawing.Size(100, 20)
        Me.txtWin7Width.TabIndex = 21
        Me.txtWin7Width.Text = "0"
        '
        'txtWin7Length
        '
        Me.txtWin7Length.Location = New System.Drawing.Point(81, 209)
        Me.txtWin7Length.Name = "txtWin7Length"
        Me.txtWin7Length.Size = New System.Drawing.Size(100, 20)
        Me.txtWin7Length.TabIndex = 20
        Me.txtWin7Length.Text = "0"
        '
        'txtWin6SA
        '
        Me.txtWin6SA.Enabled = False
        Me.txtWin6SA.Location = New System.Drawing.Point(356, 183)
        Me.txtWin6SA.Name = "txtWin6SA"
        Me.txtWin6SA.Size = New System.Drawing.Size(100, 20)
        Me.txtWin6SA.TabIndex = 19
        '
        'txtWin6Width
        '
        Me.txtWin6Width.Location = New System.Drawing.Point(218, 183)
        Me.txtWin6Width.Name = "txtWin6Width"
        Me.txtWin6Width.Size = New System.Drawing.Size(100, 20)
        Me.txtWin6Width.TabIndex = 18
        Me.txtWin6Width.Text = "0"
        '
        'txtWin6Length
        '
        Me.txtWin6Length.Location = New System.Drawing.Point(81, 183)
        Me.txtWin6Length.Name = "txtWin6Length"
        Me.txtWin6Length.Size = New System.Drawing.Size(100, 20)
        Me.txtWin6Length.TabIndex = 17
        Me.txtWin6Length.Text = "0"
        '
        'txtWin5SA
        '
        Me.txtWin5SA.Enabled = False
        Me.txtWin5SA.Location = New System.Drawing.Point(356, 157)
        Me.txtWin5SA.Name = "txtWin5SA"
        Me.txtWin5SA.Size = New System.Drawing.Size(100, 20)
        Me.txtWin5SA.TabIndex = 16
        '
        'txtWin5Width
        '
        Me.txtWin5Width.Location = New System.Drawing.Point(218, 157)
        Me.txtWin5Width.Name = "txtWin5Width"
        Me.txtWin5Width.Size = New System.Drawing.Size(100, 20)
        Me.txtWin5Width.TabIndex = 15
        Me.txtWin5Width.Text = "0"
        '
        'txtWin5Length
        '
        Me.txtWin5Length.Location = New System.Drawing.Point(81, 157)
        Me.txtWin5Length.Name = "txtWin5Length"
        Me.txtWin5Length.Size = New System.Drawing.Size(100, 20)
        Me.txtWin5Length.TabIndex = 14
        Me.txtWin5Length.Text = "0"
        '
        'txtWin4SA
        '
        Me.txtWin4SA.Enabled = False
        Me.txtWin4SA.Location = New System.Drawing.Point(356, 131)
        Me.txtWin4SA.Name = "txtWin4SA"
        Me.txtWin4SA.Size = New System.Drawing.Size(100, 20)
        Me.txtWin4SA.TabIndex = 13
        '
        'txtWin4Width
        '
        Me.txtWin4Width.Location = New System.Drawing.Point(218, 131)
        Me.txtWin4Width.Name = "txtWin4Width"
        Me.txtWin4Width.Size = New System.Drawing.Size(100, 20)
        Me.txtWin4Width.TabIndex = 12
        Me.txtWin4Width.Text = "0"
        '
        'txtWin4Length
        '
        Me.txtWin4Length.Location = New System.Drawing.Point(81, 131)
        Me.txtWin4Length.Name = "txtWin4Length"
        Me.txtWin4Length.Size = New System.Drawing.Size(100, 20)
        Me.txtWin4Length.TabIndex = 11
        Me.txtWin4Length.Text = "0"
        '
        'txtWin3SA
        '
        Me.txtWin3SA.Enabled = False
        Me.txtWin3SA.Location = New System.Drawing.Point(356, 105)
        Me.txtWin3SA.Name = "txtWin3SA"
        Me.txtWin3SA.Size = New System.Drawing.Size(100, 20)
        Me.txtWin3SA.TabIndex = 10
        '
        'txtWin3Width
        '
        Me.txtWin3Width.Location = New System.Drawing.Point(218, 105)
        Me.txtWin3Width.Name = "txtWin3Width"
        Me.txtWin3Width.Size = New System.Drawing.Size(100, 20)
        Me.txtWin3Width.TabIndex = 9
        Me.txtWin3Width.Text = "0"
        '
        'txtWin3Length
        '
        Me.txtWin3Length.Location = New System.Drawing.Point(81, 105)
        Me.txtWin3Length.Name = "txtWin3Length"
        Me.txtWin3Length.Size = New System.Drawing.Size(100, 20)
        Me.txtWin3Length.TabIndex = 8
        Me.txtWin3Length.Text = "0"
        '
        'txtWin2SA
        '
        Me.txtWin2SA.Enabled = False
        Me.txtWin2SA.Location = New System.Drawing.Point(356, 80)
        Me.txtWin2SA.Name = "txtWin2SA"
        Me.txtWin2SA.Size = New System.Drawing.Size(100, 20)
        Me.txtWin2SA.TabIndex = 7
        '
        'txtWin1SA
        '
        Me.txtWin1SA.Enabled = False
        Me.txtWin1SA.Location = New System.Drawing.Point(356, 54)
        Me.txtWin1SA.Name = "txtWin1SA"
        Me.txtWin1SA.Size = New System.Drawing.Size(100, 20)
        Me.txtWin1SA.TabIndex = 6
        '
        'txtWin2Width
        '
        Me.txtWin2Width.Location = New System.Drawing.Point(218, 80)
        Me.txtWin2Width.Name = "txtWin2Width"
        Me.txtWin2Width.Size = New System.Drawing.Size(100, 20)
        Me.txtWin2Width.TabIndex = 5
        Me.txtWin2Width.Text = "0"
        '
        'txtWin2Length
        '
        Me.txtWin2Length.Location = New System.Drawing.Point(81, 80)
        Me.txtWin2Length.Name = "txtWin2Length"
        Me.txtWin2Length.Size = New System.Drawing.Size(100, 20)
        Me.txtWin2Length.TabIndex = 4
        Me.txtWin2Length.Text = "0"
        '
        'txtWin1Width
        '
        Me.txtWin1Width.Location = New System.Drawing.Point(218, 54)
        Me.txtWin1Width.Name = "txtWin1Width"
        Me.txtWin1Width.Size = New System.Drawing.Size(100, 20)
        Me.txtWin1Width.TabIndex = 3
        Me.txtWin1Width.Text = "0"
        '
        'txtWin1Length
        '
        Me.txtWin1Length.Location = New System.Drawing.Point(81, 54)
        Me.txtWin1Length.Name = "txtWin1Length"
        Me.txtWin1Length.Size = New System.Drawing.Size(100, 20)
        Me.txtWin1Length.TabIndex = 2
        Me.txtWin1Length.Text = "0"
        '
        'lblWinWidth
        '
        Me.lblWinWidth.AutoSize = True
        Me.lblWinWidth.Location = New System.Drawing.Point(246, 30)
        Me.lblWinWidth.Name = "lblWinWidth"
        Me.lblWinWidth.Size = New System.Drawing.Size(40, 13)
        Me.lblWinWidth.TabIndex = 1
        Me.lblWinWidth.Text = "Width"
        '
        'lblWinLength
        '
        Me.lblWinLength.AutoSize = True
        Me.lblWinLength.Location = New System.Drawing.Point(109, 30)
        Me.lblWinLength.Name = "lblWinLength"
        Me.lblWinLength.Size = New System.Drawing.Size(46, 13)
        Me.lblWinLength.TabIndex = 0
        Me.lblWinLength.Text = "Length"
        '
        'grpDoor
        '
        Me.grpDoor.Controls.Add(Me.txtTotalDoorSA)
        Me.grpDoor.Controls.Add(Me.lblDoorTotal)
        Me.grpDoor.Controls.Add(Me.lblDoor4)
        Me.grpDoor.Controls.Add(Me.lblDoorSA)
        Me.grpDoor.Controls.Add(Me.lblDoor3)
        Me.grpDoor.Controls.Add(Me.lblDoor2)
        Me.grpDoor.Controls.Add(Me.txtDoor4SA)
        Me.grpDoor.Controls.Add(Me.lblDoor1)
        Me.grpDoor.Controls.Add(Me.txtDoor4Width)
        Me.grpDoor.Controls.Add(Me.txtDoor4Length)
        Me.grpDoor.Controls.Add(Me.txtDoor3SA)
        Me.grpDoor.Controls.Add(Me.txtDoor3Width)
        Me.grpDoor.Controls.Add(Me.txtDoor3Length)
        Me.grpDoor.Controls.Add(Me.txtDoor2SA)
        Me.grpDoor.Controls.Add(Me.txtDoor1SA)
        Me.grpDoor.Controls.Add(Me.txtDoor2Width)
        Me.grpDoor.Controls.Add(Me.txtDoor2Length)
        Me.grpDoor.Controls.Add(Me.txtDoor1Width)
        Me.grpDoor.Controls.Add(Me.txtDoor1Length)
        Me.grpDoor.Controls.Add(Me.lblDoorWidth)
        Me.grpDoor.Controls.Add(Me.lblDoorLength)
        Me.grpDoor.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpDoor.Location = New System.Drawing.Point(251, 302)
        Me.grpDoor.Name = "grpDoor"
        Me.grpDoor.Size = New System.Drawing.Size(471, 180)
        Me.grpDoor.TabIndex = 26
        Me.grpDoor.TabStop = False
        Me.grpDoor.Text = "Please Enter the Door Dimensions in the Boxes Below"
        '
        'txtTotalDoorSA
        '
        Me.txtTotalDoorSA.Enabled = False
        Me.txtTotalDoorSA.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalDoorSA.Location = New System.Drawing.Point(355, 151)
        Me.txtTotalDoorSA.Name = "txtTotalDoorSA"
        Me.txtTotalDoorSA.Size = New System.Drawing.Size(100, 26)
        Me.txtTotalDoorSA.TabIndex = 12
        '
        'lblDoorTotal
        '
        Me.lblDoorTotal.AutoSize = True
        Me.lblDoorTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDoorTotal.Location = New System.Drawing.Point(268, 154)
        Me.lblDoorTotal.Name = "lblDoorTotal"
        Me.lblDoorTotal.Size = New System.Drawing.Size(49, 20)
        Me.lblDoorTotal.TabIndex = 12
        Me.lblDoorTotal.Text = "Total"
        '
        'lblDoor4
        '
        Me.lblDoor4.AutoSize = True
        Me.lblDoor4.Location = New System.Drawing.Point(30, 129)
        Me.lblDoor4.Name = "lblDoor4"
        Me.lblDoor4.Size = New System.Drawing.Size(45, 13)
        Me.lblDoor4.TabIndex = 38
        Me.lblDoor4.Text = "Door 4"
        '
        'lblDoorSA
        '
        Me.lblDoorSA.AutoSize = True
        Me.lblDoorSA.Location = New System.Drawing.Point(365, 26)
        Me.lblDoorSA.Name = "lblDoorSA"
        Me.lblDoorSA.Size = New System.Drawing.Size(81, 13)
        Me.lblDoorSA.TabIndex = 27
        Me.lblDoorSA.Text = "Surface Area"
        '
        'lblDoor3
        '
        Me.lblDoor3.AutoSize = True
        Me.lblDoor3.Location = New System.Drawing.Point(30, 103)
        Me.lblDoor3.Name = "lblDoor3"
        Me.lblDoor3.Size = New System.Drawing.Size(45, 13)
        Me.lblDoor3.TabIndex = 37
        Me.lblDoor3.Text = "Door 3"
        '
        'lblDoor2
        '
        Me.lblDoor2.AutoSize = True
        Me.lblDoor2.Location = New System.Drawing.Point(30, 78)
        Me.lblDoor2.Name = "lblDoor2"
        Me.lblDoor2.Size = New System.Drawing.Size(45, 13)
        Me.lblDoor2.TabIndex = 36
        Me.lblDoor2.Text = "Door 2"
        '
        'txtDoor4SA
        '
        Me.txtDoor4SA.Enabled = False
        Me.txtDoor4SA.Location = New System.Drawing.Point(356, 126)
        Me.txtDoor4SA.Name = "txtDoor4SA"
        Me.txtDoor4SA.Size = New System.Drawing.Size(100, 20)
        Me.txtDoor4SA.TabIndex = 13
        '
        'lblDoor1
        '
        Me.lblDoor1.AutoSize = True
        Me.lblDoor1.Location = New System.Drawing.Point(30, 52)
        Me.lblDoor1.Name = "lblDoor1"
        Me.lblDoor1.Size = New System.Drawing.Size(45, 13)
        Me.lblDoor1.TabIndex = 35
        Me.lblDoor1.Text = "Door 1"
        '
        'txtDoor4Width
        '
        Me.txtDoor4Width.Location = New System.Drawing.Point(218, 126)
        Me.txtDoor4Width.Name = "txtDoor4Width"
        Me.txtDoor4Width.Size = New System.Drawing.Size(100, 20)
        Me.txtDoor4Width.TabIndex = 12
        Me.txtDoor4Width.Text = "0"
        '
        'txtDoor4Length
        '
        Me.txtDoor4Length.Location = New System.Drawing.Point(81, 126)
        Me.txtDoor4Length.Name = "txtDoor4Length"
        Me.txtDoor4Length.Size = New System.Drawing.Size(100, 20)
        Me.txtDoor4Length.TabIndex = 11
        Me.txtDoor4Length.Text = "0"
        '
        'txtDoor3SA
        '
        Me.txtDoor3SA.Enabled = False
        Me.txtDoor3SA.Location = New System.Drawing.Point(356, 100)
        Me.txtDoor3SA.Name = "txtDoor3SA"
        Me.txtDoor3SA.Size = New System.Drawing.Size(100, 20)
        Me.txtDoor3SA.TabIndex = 10
        '
        'txtDoor3Width
        '
        Me.txtDoor3Width.Location = New System.Drawing.Point(218, 100)
        Me.txtDoor3Width.Name = "txtDoor3Width"
        Me.txtDoor3Width.Size = New System.Drawing.Size(100, 20)
        Me.txtDoor3Width.TabIndex = 9
        Me.txtDoor3Width.Text = "0"
        '
        'txtDoor3Length
        '
        Me.txtDoor3Length.Location = New System.Drawing.Point(81, 100)
        Me.txtDoor3Length.Name = "txtDoor3Length"
        Me.txtDoor3Length.Size = New System.Drawing.Size(100, 20)
        Me.txtDoor3Length.TabIndex = 8
        Me.txtDoor3Length.Text = "0"
        '
        'txtDoor2SA
        '
        Me.txtDoor2SA.Enabled = False
        Me.txtDoor2SA.Location = New System.Drawing.Point(356, 75)
        Me.txtDoor2SA.Name = "txtDoor2SA"
        Me.txtDoor2SA.Size = New System.Drawing.Size(100, 20)
        Me.txtDoor2SA.TabIndex = 7
        '
        'txtDoor1SA
        '
        Me.txtDoor1SA.Enabled = False
        Me.txtDoor1SA.Location = New System.Drawing.Point(356, 49)
        Me.txtDoor1SA.Name = "txtDoor1SA"
        Me.txtDoor1SA.Size = New System.Drawing.Size(100, 20)
        Me.txtDoor1SA.TabIndex = 6
        '
        'txtDoor2Width
        '
        Me.txtDoor2Width.Location = New System.Drawing.Point(218, 75)
        Me.txtDoor2Width.Name = "txtDoor2Width"
        Me.txtDoor2Width.Size = New System.Drawing.Size(100, 20)
        Me.txtDoor2Width.TabIndex = 5
        Me.txtDoor2Width.Text = "0"
        '
        'txtDoor2Length
        '
        Me.txtDoor2Length.Location = New System.Drawing.Point(81, 75)
        Me.txtDoor2Length.Name = "txtDoor2Length"
        Me.txtDoor2Length.Size = New System.Drawing.Size(100, 20)
        Me.txtDoor2Length.TabIndex = 4
        Me.txtDoor2Length.Text = "0"
        '
        'txtDoor1Width
        '
        Me.txtDoor1Width.Location = New System.Drawing.Point(218, 49)
        Me.txtDoor1Width.Name = "txtDoor1Width"
        Me.txtDoor1Width.Size = New System.Drawing.Size(100, 20)
        Me.txtDoor1Width.TabIndex = 3
        Me.txtDoor1Width.Text = "0"
        '
        'txtDoor1Length
        '
        Me.txtDoor1Length.Location = New System.Drawing.Point(81, 49)
        Me.txtDoor1Length.Name = "txtDoor1Length"
        Me.txtDoor1Length.Size = New System.Drawing.Size(100, 20)
        Me.txtDoor1Length.TabIndex = 2
        Me.txtDoor1Length.Text = "0"
        '
        'lblDoorWidth
        '
        Me.lblDoorWidth.AutoSize = True
        Me.lblDoorWidth.Location = New System.Drawing.Point(246, 25)
        Me.lblDoorWidth.Name = "lblDoorWidth"
        Me.lblDoorWidth.Size = New System.Drawing.Size(40, 13)
        Me.lblDoorWidth.TabIndex = 1
        Me.lblDoorWidth.Text = "Width"
        '
        'lblDoorLength
        '
        Me.lblDoorLength.AutoSize = True
        Me.lblDoorLength.Location = New System.Drawing.Point(109, 25)
        Me.lblDoorLength.Name = "lblDoorLength"
        Me.lblDoorLength.Size = New System.Drawing.Size(46, 13)
        Me.lblDoorLength.TabIndex = 0
        Me.lblDoorLength.Text = "Length"
        '
        'lblPaint
        '
        Me.lblPaint.AutoSize = True
        Me.lblPaint.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPaint.Location = New System.Drawing.Point(19, 496)
        Me.lblPaint.Name = "lblPaint"
        Me.lblPaint.Size = New System.Drawing.Size(298, 29)
        Me.lblPaint.TabIndex = 27
        Me.lblPaint.Text = "Gallons of Paint Needed"
        '
        'txtPaint
        '
        Me.txtPaint.Enabled = False
        Me.txtPaint.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPaint.Location = New System.Drawing.Point(336, 493)
        Me.txtPaint.Name = "txtPaint"
        Me.txtPaint.Size = New System.Drawing.Size(174, 35)
        Me.txtPaint.TabIndex = 39
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.Location = New System.Drawing.Point(539, 493)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(163, 34)
        Me.btnCalculate.TabIndex = 40
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'PennsylvaniaPaintCompany
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(732, 758)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtPaint)
        Me.Controls.Add(Me.lblPaint)
        Me.Controls.Add(Me.grpDoor)
        Me.Controls.Add(Me.grpWin)
        Me.Controls.Add(Me.grpRoomDims)
        Me.Controls.Add(Me.grpWallSA)
        Me.Name = "PennsylvaniaPaintCompany"
        Me.Text = "Pennsylvania Paint Company Estimate Generator"
        Me.grpRoomDims.ResumeLayout(False)
        Me.grpRoomDims.PerformLayout()
        Me.grpWallSA.ResumeLayout(False)
        Me.grpWallSA.PerformLayout()
        Me.grpWin.ResumeLayout(False)
        Me.grpWin.PerformLayout()
        Me.grpDoor.ResumeLayout(False)
        Me.grpDoor.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents grpRoomDims As System.Windows.Forms.GroupBox
    Friend WithEvents txtRoomHeight As System.Windows.Forms.TextBox
    Friend WithEvents lblRoomHeight As System.Windows.Forms.Label
    Friend WithEvents txtRoomLength As System.Windows.Forms.TextBox
    Friend WithEvents lblRoomLength As System.Windows.Forms.Label
    Friend WithEvents lblRoomWidth As System.Windows.Forms.Label
    Friend WithEvents txtRoomWidth As System.Windows.Forms.TextBox
    Friend WithEvents grpWallSA As System.Windows.Forms.GroupBox
    Friend WithEvents lblWall4SA As System.Windows.Forms.Label
    Friend WithEvents lblWall3SA As System.Windows.Forms.Label
    Friend WithEvents lblWall2SA As System.Windows.Forms.Label
    Friend WithEvents lblWall1SA As System.Windows.Forms.Label
    Friend WithEvents lblCeilingSA As System.Windows.Forms.Label
    Friend WithEvents txtWall4SA As System.Windows.Forms.TextBox
    Friend WithEvents txtWall3SA As System.Windows.Forms.TextBox
    Friend WithEvents txtWall2SA As System.Windows.Forms.TextBox
    Friend WithEvents txtWall1SA As System.Windows.Forms.TextBox
    Friend WithEvents txtCeilingSA As System.Windows.Forms.TextBox
    Friend WithEvents grpWin As System.Windows.Forms.GroupBox
    Friend WithEvents lblWin8 As System.Windows.Forms.Label
    Friend WithEvents lblWin7 As System.Windows.Forms.Label
    Friend WithEvents lblWin6 As System.Windows.Forms.Label
    Friend WithEvents lblWin5 As System.Windows.Forms.Label
    Friend WithEvents lblWin4 As System.Windows.Forms.Label
    Friend WithEvents lblWin3 As System.Windows.Forms.Label
    Friend WithEvents lblWin2 As System.Windows.Forms.Label
    Friend WithEvents lblWin1 As System.Windows.Forms.Label
    Friend WithEvents lblWinSA As System.Windows.Forms.Label
    Friend WithEvents txtWin8SA As System.Windows.Forms.TextBox
    Friend WithEvents txtWin8Width As System.Windows.Forms.TextBox
    Friend WithEvents txtWin8Length As System.Windows.Forms.TextBox
    Friend WithEvents txtWin7SA As System.Windows.Forms.TextBox
    Friend WithEvents txtWin7Width As System.Windows.Forms.TextBox
    Friend WithEvents txtWin7Length As System.Windows.Forms.TextBox
    Friend WithEvents txtWin6SA As System.Windows.Forms.TextBox
    Friend WithEvents txtWin6Width As System.Windows.Forms.TextBox
    Friend WithEvents txtWin6Length As System.Windows.Forms.TextBox
    Friend WithEvents txtWin5SA As System.Windows.Forms.TextBox
    Friend WithEvents txtWin5Width As System.Windows.Forms.TextBox
    Friend WithEvents txtWin5Length As System.Windows.Forms.TextBox
    Friend WithEvents txtWin4SA As System.Windows.Forms.TextBox
    Friend WithEvents txtWin4Width As System.Windows.Forms.TextBox
    Friend WithEvents txtWin4Length As System.Windows.Forms.TextBox
    Friend WithEvents txtWin3SA As System.Windows.Forms.TextBox
    Friend WithEvents txtWin3Width As System.Windows.Forms.TextBox
    Friend WithEvents txtWin3Length As System.Windows.Forms.TextBox
    Friend WithEvents txtWin2SA As System.Windows.Forms.TextBox
    Friend WithEvents txtWin1SA As System.Windows.Forms.TextBox
    Friend WithEvents txtWin2Width As System.Windows.Forms.TextBox
    Friend WithEvents txtWin2Length As System.Windows.Forms.TextBox
    Friend WithEvents txtWin1Width As System.Windows.Forms.TextBox
    Friend WithEvents txtWin1Length As System.Windows.Forms.TextBox
    Friend WithEvents lblWinWidth As System.Windows.Forms.Label
    Friend WithEvents lblWinLength As System.Windows.Forms.Label
    Friend WithEvents grpDoor As System.Windows.Forms.GroupBox
    Friend WithEvents lblDoorSA As System.Windows.Forms.Label
    Friend WithEvents txtDoor4SA As System.Windows.Forms.TextBox
    Friend WithEvents txtDoor4Width As System.Windows.Forms.TextBox
    Friend WithEvents txtDoor4Length As System.Windows.Forms.TextBox
    Friend WithEvents txtDoor3SA As System.Windows.Forms.TextBox
    Friend WithEvents txtDoor3Width As System.Windows.Forms.TextBox
    Friend WithEvents txtDoor3Length As System.Windows.Forms.TextBox
    Friend WithEvents txtDoor2SA As System.Windows.Forms.TextBox
    Friend WithEvents txtDoor1SA As System.Windows.Forms.TextBox
    Friend WithEvents txtDoor2Width As System.Windows.Forms.TextBox
    Friend WithEvents txtDoor2Length As System.Windows.Forms.TextBox
    Friend WithEvents txtDoor1Width As System.Windows.Forms.TextBox
    Friend WithEvents txtDoor1Length As System.Windows.Forms.TextBox
    Friend WithEvents lblDoorWidth As System.Windows.Forms.Label
    Friend WithEvents lblDoorLength As System.Windows.Forms.Label
    Friend WithEvents lblDoor4 As System.Windows.Forms.Label
    Friend WithEvents lblDoor3 As System.Windows.Forms.Label
    Friend WithEvents lblDoor2 As System.Windows.Forms.Label
    Friend WithEvents lblDoor1 As System.Windows.Forms.Label
    Friend WithEvents lblWallTotal As System.Windows.Forms.Label
    Friend WithEvents txtTotalWallSA As System.Windows.Forms.TextBox
    Friend WithEvents txtTotalWinSA As System.Windows.Forms.TextBox
    Friend WithEvents lblWinTotal As System.Windows.Forms.Label
    Friend WithEvents txtTotalDoorSA As System.Windows.Forms.TextBox
    Friend WithEvents lblDoorTotal As System.Windows.Forms.Label
    Friend WithEvents lblPaint As System.Windows.Forms.Label
    Friend WithEvents txtPaint As System.Windows.Forms.TextBox
    Friend WithEvents btnCalculate As System.Windows.Forms.Button

End Class
